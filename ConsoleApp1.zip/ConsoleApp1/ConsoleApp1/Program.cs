﻿using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            BaseRequest baseRequest = new BaseRequest();
            baseRequest.SourceId = "STZ";
            baseRequest.ReferenceNo = "SBIST00000111202103087279";
            HRMSDetails(baseRequest);

            Console.ReadLine();

        }

        public static string HRMSDetails(BaseRequest req)
        {
            //string PF_NUMBER="";
            //string SOURCE_ID="";
            RequestResponseMaster rrm = new RequestResponseMaster();
            Console.WriteLine("Inside HRMSDetails:");
            string json = string.Empty;
            string rsaEncKey = string.Empty;
            string payload = string.Empty;
            string key = string.Empty;
            string digiSign = string.Empty;
            string strPFNumber = "6237754";
            rrm.URL = ApiConfig.HRMS_Details;
            rrm.TransactionId = req.ReferenceNo;// refno;
            try
            {
                //json = "{\"PF_NUMBER\":\"" + strPFNumber + "\"," +
                //                    "\"SOURCE_ID\":\"" + req.SourceId + "\"," +
                //                    "\"REQUEST_REFERENCE_NUMBER\":\"" + req.ReferenceNo + "\"}";

                json = "{\"PF_NUMBER\":\"" + strPFNumber + "\"," +
                    "\"SOURCE_ID\":\"" + req.SourceId + "\"}";

                rrm.PlainRequest = json;
                var rsaJson = AESEncryptionWithIIB(json, ApiConfig.EISPublicCertPath, ApiConfig.DigiSignCertPath, out rsaEncKey, out key, out digiSign);
                Console.WriteLine("After CryptoEngine.AESEncryptionWithIIB:");
                Console.WriteLine("Before SSL:");
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                Console.WriteLine("After SSL:");
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(ApiConfig.HRMS_Details);
                Console.WriteLine("After HTTPWebRequest:");
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                httpWebRequest.Headers.Add("AccessToken", rsaEncKey);

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    payload = "{\"REQUEST_REFERENCE_NUMBER\":\"" + req.ReferenceNo + "\"," +
                                "\"REQUEST\":\"" + rsaJson + "\"," +
                                "\"DIGI_SIGN\":\"" + digiSign + "\"}";

                    streamWriter.Write(payload);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                Console.WriteLine("HRMSDetails Encrypted Payload Request:" + payload);
                rrm.APIRequest = payload;

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    Console.WriteLine("HRMSDetails Received the Response:");
                    var result = streamReader.ReadToEnd();
                    JObject objresult = JObject.Parse(result);
                    Console.WriteLine("HRMSDetails Json Object:" + result);
                    if (objresult.ContainsKey("RESPONSE"))
                    {
                        var encResponse = objresult["RESPONSE"].ToString();
                        //Console.WriteLine("HRMSDetails Encrypted Response:" + encResponse);
                        var referenceNo = objresult["REQUEST_REFERENCE_NUMBER"].ToString();
                        var digiSignResponse = objresult["DIGI_SIGN"].ToString();
                        var decResult = AESDecryptionWithIIB(encResponse, key, digiSignResponse, ApiConfig.EISPublicCertPath);
                        string[] decResponse = decResult.Split('|');

                        Console.WriteLine("HRMS API Decrypted  Response:" + decResponse[1]);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error:" + ex.Message.ToString());
            }

            return "";
        }



        public static string AESEncryptionWithIIB(string toEncrypt, string rsaCertPath, string rsaDigiSignCertPath, out string rsaEncKey, out string key, out string digiSign)
        {
            byte[] encrypted;
            using (AesManaged aesCipher = new AesManaged())
            {
                aesCipher.Mode = CipherMode.CBC;
                aesCipher.Padding = PaddingMode.PKCS7;
                aesCipher.KeySize = 256;
                aesCipher.GenerateKey();

                var base64Key = Convert.ToBase64String(aesCipher.Key);
                var keyBytes = Encoding.UTF8.GetBytes(base64Key.Substring(0, 32));
                aesCipher.Key = keyBytes;
                key = Encoding.UTF8.GetString(keyBytes);
                Console.WriteLine("Rsa Encryption Start:");
                var rsaEncryption = RsaEncryptionOAEP(aesCipher.Key, rsaCertPath);
                Console.WriteLine("Rsa Encryption End:");
                rsaEncKey = rsaEncryption;
                Console.WriteLine("Digi Sign Start:");
                var sign = DigiSign(toEncrypt, rsaDigiSignCertPath);
                Console.WriteLine("Digi Sign End:");
                digiSign = sign;
                aesCipher.IV = aesCipher.Key.Take(16).ToArray();
                var encryptor = aesCipher.CreateEncryptor(aesCipher.Key, aesCipher.IV);

                using (var msEncrypt = new MemoryStream())
                {
                    using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.
                            swEncrypt.Write(toEncrypt);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }
            Console.WriteLine(Convert.ToBase64String(encrypted));
            return Convert.ToBase64String(encrypted);
        }

        private static string DigiSign(string toEncrypt, string rsaDigiSignCertPath)
        {

            // Load the digital signature certificate from a file or store
            X509Certificate2 cert = new X509Certificate2(rsaDigiSignCertPath, "root123");

            // Get the private key from the certificate
            RSA rsa = (RSA)cert.GetRSAPrivateKey();

            // Sign the data with the private key
            byte[] dataToSign = Encoding.UTF8.GetBytes(toEncrypt);
            byte[] signature = rsa.SignData(dataToSign, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);

            return Convert.ToBase64String(signature);
        }

        private static string RsaEncryptionOAEP(byte[] key, string rsaCertPath)
        {
            // Set OAEP padding
            RSAEncryptionPadding encryptionPadding = RSAEncryptionPadding.OaepSHA256;

            X509Certificate2 cert = new X509Certificate2(rsaCertPath);
            // Get the public key from the certificate
            RSA rsa = (RSA)cert.PublicKey.Key;
            byte[] encryptedAesKey = rsa.Encrypt(key, encryptionPadding);

            return Convert.ToBase64String(encryptedAesKey);
        }

        public static string AESDecryptionWithIIB(string toDecrypt, string key, string recDigiSign, string rsaCertPath)
        {
            string plaintext;

            using (AesManaged aesCipher = new AesManaged())
            {
                aesCipher.Mode = CipherMode.CBC;
                aesCipher.Padding = PaddingMode.PKCS7;
                aesCipher.KeySize = 256;

                aesCipher.Key = Encoding.UTF8.GetBytes(key);
                aesCipher.IV = aesCipher.Key.Take(16).ToArray();

                var decryptor = aesCipher.CreateDecryptor(aesCipher.Key, aesCipher.IV);
                var encrypted = Convert.FromBase64String(toDecrypt);

                using (var msDecrypt = new MemoryStream(encrypted))
                {
                    using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (var srDecrypt = new StreamReader(csDecrypt))
                        {
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }

                //Console.WriteLine("Decrypted Response:" + plaintext);
            }
            //Console.WriteLine("Received Signature:" + recDigiSign);
            bool valid = CheckSign(recDigiSign, plaintext, rsaCertPath);
            if (valid)
            {
                Console.WriteLine("Digi Sign Verified");
                return "00|" + plaintext;
            }
            else
            {
                Console.WriteLine("Digi Sign not Verified");
                return "01|" + plaintext;
            }
        }

        private static bool CheckSign(string recDigiSign, string plaintext, string rsaCertPath)
        {
            // Load the digital signature certificate from a file or store
            X509Certificate2 cert = new X509Certificate2(rsaCertPath);

            // Get the private key from the certificate
            RSA rsa = (RSA)cert.GetRSAPrivateKey();

            // Sign the data with the private key
            byte[] dataToSign = Encoding.UTF8.GetBytes(plaintext);
            byte[] signature = Encoding.ASCII.GetBytes(recDigiSign);

            // Verify the signature with the public key
            RSACryptoServiceProvider publicKey = (RSACryptoServiceProvider)cert.PublicKey.Key;
            bool isSignatureValid = publicKey.VerifyData(dataToSign, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);

            return isSignatureValid;
        }
    }

    internal class RequestResponseMaster
    {
        internal object TransactionId;
        public string URL { get; set; }
        public string APIRequest { get; set; }
        public string PlainRequest { get; set; }
    }

    internal class ApiConfig
    {
        public static string EISPublicCertPath = "C:/Users/amitm/source/repos/ConsoleApp1/ConsoleApp1/Certificate/PowerAppsGatewayPublicKey.cer";
        public static string DigiSignCertPath = "C:/Users/amitm/source/repos/ConsoleApp1/ConsoleApp1/Certificate/SFGAPPUAT.pfx";

        public static string HRMS_Details = "https://eisuat.sbi.co.in/gen5/gateway/employee/pf/details";
    }

    public class BaseRequest
    {
        public string SourceId { get; set; }
        public object ReferenceNo { get; set; }
    }
}
